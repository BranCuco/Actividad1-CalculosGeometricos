namespace CalculadoraGeometrica
{
    class Cuadrado
    {
        private double Lado { get; set; }

        public Cuadrado(double lado)
        {
            Lado = lado;
        }

        public double CalcularPerimetro()
        {
            return 4 * Lado;
        }

        public double CalcularArea()
        {
            return Lado * Lado;
        }
    }
}
