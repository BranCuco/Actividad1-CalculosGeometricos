using System;
using System.Windows.Forms;

namespace CalculadoraGeometrica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int opcion = cmbFiguras.SelectedIndex;

            if (opcion == 1) // Si se selecciona Círculo
            {
                if (double.TryParse(txtDato1.Text, out double radio) && radio > 0)
                {
                    Circulo circulo = new Circulo(radio);
                    lblResultado.Text = $"Perímetro: {circulo.CalcularPerimetro()}, Área: {circulo.CalcularArea()}, Diámetro: {circulo.CalcularDiametro()}";
                }
                else
                {
                    lblResultado.Text = "Por favor, ingrese un radio válido.";
                }
            }
            else // Para otras figuras
            {
                if (double.TryParse(txtDato1.Text, out double dato1) && double.TryParse(txtDato2.Text, out double dato2))
                {
                    switch (opcion)
                    {
                        case 0: // Rectángulo
                            Rectangulo rectangulo = new Rectangulo(dato1, dato2);
                            lblResultado.Text = $"Perímetro: {rectangulo.CalcularPerimetro()}, Área: {rectangulo.CalcularArea()}";
                            break;
                        case 2: // Cuadrado
                            Cuadrado cuadrado = new Cuadrado(dato1);
                            lblResultado.Text = $"Perímetro: {cuadrado.CalcularPerimetro()}, Área: {cuadrado.CalcularArea()}";
                            break;
                        case 3: // Triángulo
                            Triangulo triangulo = new Triangulo(dato1, dato2);
                            lblResultado.Text = $"Perímetro: {triangulo.CalcularPerimetro()}, Área: {triangulo.CalcularArea()}";
                            break;
                        default:
                            lblResultado.Text = "Seleccione una figura.";
                            break;
                    }
                }
                else
                {
                    lblResultado.Text = "Por favor, ingrese números válidos.";
                }
            }
        }


        private void cmbFiguras_SelectedIndexChanged(object sender, EventArgs e)
        {
            int opcion = cmbFiguras.SelectedIndex;

            switch (opcion)
            {
                case 0: // Rectángulo
                case 2: // Cuadrado
                case 3: // Triángulo
                    label2.Text = "Dato 1 (b):";
                    label3.Text = "Dato 2 (h):";
                    txtDato2.Visible = true;
                    break;
                case 1: // Círculo
                    label2.Text = "Radio:";
                    label3.Text = "";
                    txtDato2.Visible = false;
                    break;
                default:
                    label2.Text = "Dato 1:";
                    label3.Text = "Dato 2:";
                    txtDato2.Visible = true;
                    break;
            }
        }
    }
}
