namespace CalculadoraGeometrica
{
    class Rectangulo
    {
        private double Base { get; set; }
        private double Altura { get; set; }

        public Rectangulo(double b, double h)
        {
            Base = b;
            Altura = h;
        }

        public double CalcularPerimetro()
        {
            return 2 * (Base + Altura);
        }

        public double CalcularArea()
        {
            return Base * Altura;
        }
    }
}
