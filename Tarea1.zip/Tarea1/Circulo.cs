namespace CalculadoraGeometrica
{
    class Circulo
    {
        private double Radio { get; set; }

        public Circulo(double radio)
        {
            Radio = radio;
        }

        public double CalcularPerimetro()
        {
            return 2 * Math.PI * Radio;
        }

        public double CalcularArea()
        {
            return Math.PI * Math.Pow(Radio, 2);
        }

        public double CalcularDiametro()
        {
            return 2 * Radio;
        }
    }
}
