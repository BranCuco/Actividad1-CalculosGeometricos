namespace CalculadoraGeometrica
{
    class Triangulo
    {
        private double Base { get; set; }
        private double Altura { get; set; }

        public Triangulo(double b, double h)
        {
            Base = b;
            Altura = h;
        }

        public double CalcularPerimetro()
        {
            double lado = Math.Sqrt(Math.Pow(Base / 2, 2) + Math.Pow(Altura, 2));
            return 2 * lado + Base;
        }

        public double CalcularArea()
        {
            return (Base * Altura) / 2;
        }
    }
}
